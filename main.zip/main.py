# ==========================================
# HEART DISEASE PREDICTION
# CNN + GRU + FEATURE FUSION MODEL
# WITH ALL PLOTS
# ==========================================

# pip install pandas numpy matplotlib seaborn scikit-learn tensorflow

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    roc_curve,
    auc,
    precision_recall_curve
)

from tensorflow.keras.models import Model
from tensorflow.keras.layers import (
    Input,
    Conv1D,
    MaxPooling1D,
    GRU,
    Dense,
    Flatten,
    Concatenate,
    Dropout
)

from tensorflow.keras.optimizers import Adam

# ==========================================
# LOAD DATASET
# ==========================================

data = pd.read_csv("heart.csv")

print(data.head())

# ==========================================
# DATA VISUALIZATION
# ==========================================

# Target Count Plot
plt.figure(figsize=(6,5))
sns.countplot(x='target', data=data)
plt.title("Target Class Distribution")
plt.show()

# Correlation Heatmap
plt.figure(figsize=(12,10))
sns.heatmap(data.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Histogram Plot
data.hist(figsize=(15,12))
plt.suptitle("Feature Distribution")
plt.show()

# ==========================================
# DATA PREPROCESSING
# ==========================================

X = data.drop("target", axis=1)
y = data["target"]

# Standardization
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Reshape for CNN + GRU
X = X.reshape(X.shape[0], X.shape[1], 1)

# Train Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ==========================================
# INPUT LAYER
# ==========================================

input_layer = Input(shape=(X_train.shape[1], 1))

# ==========================================
# CNN BRANCH
# ==========================================

cnn = Conv1D(
    filters=64,
    kernel_size=3,
    activation='relu'
)(input_layer)

cnn = MaxPooling1D(pool_size=2)(cnn)

cnn = Flatten()(cnn)

# ==========================================
# GRU BRANCH
# ==========================================

gru = GRU(
    64,
    return_sequences=False
)(input_layer)

# ==========================================
# FEATURE FUSION
# ==========================================

fusion = Concatenate()([cnn, gru])

fusion = Dense(128, activation='relu')(fusion)

fusion = Dropout(0.5)(fusion)

# ==========================================
# OUTPUT LAYER
# ==========================================

output = Dense(1, activation='sigmoid')(fusion)

# ==========================================
# BUILD MODEL
# ==========================================

model = Model(inputs=input_layer, outputs=output)

model.compile(
    optimizer=Adam(learning_rate=0.001),
    loss='binary_crossentropy',
    metrics=['accuracy']
)

# ==========================================
# MODEL SUMMARY
# ==========================================

model.summary()

# ==========================================
# TRAIN MODEL
# ==========================================

history = model.fit(
    X_train,
    y_train,
    epochs=50,
    batch_size=16,
    validation_split=0.2
)

# ==========================================
# PREDICTION
# ==========================================

y_prob = model.predict(X_test)

y_pred = (y_prob > 0.5).astype(int)

# ==========================================
# EVALUATION
# ==========================================

accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy:", accuracy)

print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))

# ==========================================
# CONFUSION MATRIX
# ==========================================

cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(6,5))
sns.heatmap(cm,
            annot=True,
            fmt='d',
            cmap='Blues')

plt.title("Confusion Matrix")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.show()

# ==========================================
# TRAINING ACCURACY PLOT
# ==========================================

plt.figure(figsize=(8,5))

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])

plt.title('Model Accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')

plt.legend(['Train', 'Validation'])

plt.show()

# ==========================================
# TRAINING LOSS PLOT
# ==========================================

plt.figure(figsize=(8,5))

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])

plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')

plt.legend(['Train', 'Validation'])

plt.show()

# ==========================================
# ROC CURVE
# ==========================================

fpr, tpr, threshold = roc_curve(y_test, y_prob)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8,6))

plt.plot(fpr, tpr,
         label='ROC curve (area = %0.2f)' % roc_auc)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')

plt.title('ROC Curve')

plt.legend(loc="lower right")

plt.show()

# ==========================================
# PRECISION RECALL CURVE
# ==========================================

precision, recall, _ = precision_recall_curve(y_test, y_prob)

plt.figure(figsize=(8,6))

plt.plot(recall, precision)

plt.xlabel("Recall")
plt.ylabel("Precision")

plt.title("Precision-Recall Curve")

plt.show()

# ==========================================
# FEATURE IMPORTANCE STYLE BARPLOT
# ==========================================

feature_names = data.drop("target", axis=1).columns

importance = np.abs(data.drop("target", axis=1).corrwith(data["target"]))

importance = importance.sort_values()

plt.figure(figsize=(10,6))

importance.plot(kind='barh')

plt.title("Feature Importance")

plt.xlabel("Correlation Value")

plt.show()

# ==========================================
# PREDICTION VISUALIZATION
# ==========================================

plt.figure(figsize=(10,5))

plt.plot(y_test.values[:30], label='Actual')
plt.plot(y_pred[:30], label='Predicted')

plt.title("Actual vs Predicted")

plt.xlabel("Sample")

plt.ylabel("Class")

plt.legend()

plt.show()

# ==========================================
# SAVE MODEL
# ==========================================

model.save("heart_disease_cnn_gru_model.h5")

print("\nModel Saved Successfully")



# ==========================================
# PERFORMANCE METRICS PLOTS
# FPR, FNR, KS-STATISTICS
# ==========================================

from sklearn.metrics import (
    confusion_matrix,
    roc_curve,
    auc
)

# ==========================================
# CONFUSION MATRIX VALUES
# ==========================================

cm = confusion_matrix(y_test, y_pred)

TN = cm[0][0]
FP = cm[0][1]
FN = cm[1][0]
TP = cm[1][1]

# ==========================================
# METRICS CALCULATION
# ==========================================

accuracy = (TP + TN) / (TP + TN + FP + FN)

precision = TP / (TP + FP)

recall = TP / (TP + FN)

f1_score = 2 * ((precision * recall) / (precision + recall))

specificity = TN / (TN + FP)

fpr_value = FP / (FP + TN)

fnr_value = FN / (FN + TP)

print("Accuracy :", accuracy)
print("Precision:", precision)
print("Recall   :", recall)
print("F1 Score :", f1_score)
print("Specificity :", specificity)
print("FPR :", fpr_value)
print("FNR :", fnr_value)

# ==========================================
# PERFORMANCE METRICS BAR PLOT
# ==========================================

metrics = [
    accuracy,
    precision,
    recall,
    f1_score,
    specificity
]

metric_names = [
    'Accuracy',
    'Precision',
    'Recall',
    'F1-Score',
    'Specificity'
]

plt.figure(figsize=(8,6))

bars = plt.bar(metric_names, metrics)

plt.title("Performance Metrics")

plt.ylabel("Score")

plt.ylim(0,1)

# Value labels
for bar in bars:
    yval = bar.get_height()
    plt.text(
        bar.get_x() + 0.15,
        yval + 0.01,
        round(yval,3)
    )

plt.show()

# ==========================================
# FPR vs FNR PLOT
# ==========================================

plt.figure(figsize=(6,5))

values = [fpr_value, fnr_value]

labels = ['FPR', 'FNR']

bars = plt.bar(labels, values)

plt.title("FPR and FNR")

plt.ylabel("Rate")

plt.ylim(0,1)

for bar in bars:
    yval = bar.get_height()
    plt.text(
        bar.get_x() + 0.1,
        yval + 0.01,
        round(yval,3)
    )

plt.show()

# ==========================================
# ROC CURVE
# ==========================================

fpr, tpr, thresholds = roc_curve(y_test, y_prob)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8,6))

plt.plot(
    fpr,
    tpr,
    label='AUC = %0.2f' % roc_auc
)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend(loc='lower right')

plt.show()

# ==========================================
# KS-STATISTIC CALCULATION
# ==========================================

# True Positive Rate already available -> tpr
# False Positive Rate already available -> fpr

ks_statistic = max(tpr - fpr)

ks_index = np.argmax(tpr - fpr)

ks_x = fpr[ks_index]
ks_y = tpr[ks_index]

print("\nKS Statistic:", ks_statistic)

# ==========================================
# KS-STATISTIC PLOT
# ==========================================

plt.figure(figsize=(8,6))

plt.plot(
    thresholds,
    tpr,
    label='TPR'
)

plt.plot(
    thresholds,
    fpr,
    label='FPR'
)

# KS Vertical Line
plt.vlines(
    thresholds[ks_index],
    fpr[ks_index],
    tpr[ks_index],
    linestyles='dashed'
)

plt.xlabel("Threshold")

plt.ylabel("Rate")

plt.title("KS Statistic Plot")

plt.legend()

plt.show()

# ==========================================
# KS CURVE (CDF STYLE)
# ==========================================

plt.figure(figsize=(8,6))

plt.plot(fpr, label='FPR')

plt.plot(tpr, label='TPR')

plt.axvline(
    x=ks_index,
    linestyle='--'
)

plt.title("KS Curve")

plt.xlabel("Index")

plt.ylabel("Rate")

plt.legend()

plt.show()

# ==========================================
# ERROR RATE PLOT
# ==========================================

error_rates = [
    fpr_value,
    fnr_value
]

plt.figure(figsize=(7,5))

plt.plot(
    labels,
    error_rates,
    marker='o'
)

plt.title("Error Rates")

plt.ylabel("Rate")

plt.ylim(0,1)

plt.grid(True)

plt.show()

# ==========================================
# DONUT CHART FOR CORRECT/WRONG
# ==========================================

correct = TP + TN

wrong = FP + FN

sizes = [correct, wrong]

labels = ['Correct', 'Wrong']

plt.figure(figsize=(6,6))

plt.pie(
    sizes,
    labels=labels,
    autopct='%1.1f%%',
    wedgeprops=dict(width=0.4)
)

plt.title("Prediction Distribution")

plt.show()

# ==========================================
# CLASSIFICATION RESULT PIE CHART
# ==========================================

sizes = [TP, TN, FP, FN]

labels = [
    'True Positive',
    'True Negative',
    'False Positive',
    'False Negative'
]

plt.figure(figsize=(7,7))

plt.pie(
    sizes,
    labels=labels,
    autopct='%1.1f%%'
)

plt.title("Classification Results")

plt.show()